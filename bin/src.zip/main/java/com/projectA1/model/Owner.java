package com.projectA1.model;

public class Owner {

}
