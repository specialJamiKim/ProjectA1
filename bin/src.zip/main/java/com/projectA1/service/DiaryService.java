package com.projectA1.service;

public class DiaryService {
	
}
