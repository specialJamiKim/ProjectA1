package com.projectA1.mapper;

public interface VisitCountingMapper {

}
